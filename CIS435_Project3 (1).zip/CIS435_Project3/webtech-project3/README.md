# CIS 435 - Project 3: Task Manager

## Group Members
- Mouath Nasri
- Nathalie Agalo
- Faras Abueida

## Project Overview
This project is a PHP-based Task Manager web application that allows users to create, organize, complete, and delete tasks. Task information is saved in a server-side JSON file.

The application includes a responsive interface, task validation, search functionality, and filtering and sorting options.

## Features
- Create tasks with a required title
- Add optional descriptions and due dates
- Assign Low, Medium, or High priority
- Display all saved tasks
- Search tasks by title or description
- Filter tasks by priority
- Filter tasks by status (All, To do, Completed)
- Sort tasks by newest, due date, or priority
- Mark tasks as completed
- Delete tasks
- Display validation errors and success messages
- Store task information in a JSON file

## Technologies Used
- HTML
- CSS
- PHP
- JSON

## How to Run the Project

1. Download or clone the repository.
2. Make sure PHP is installed on your computer.
3. Open a terminal in the `webtech-project3` folder.
4. Run the following command:

    php -S localhost:8000 -t public

5. Open a browser and visit:

    http://localhost:8000

The application requires a PHP server. GitHub Pages alone does not execute PHP.

## Project Structure

- `index.php` - Main Task Manager interface and task filtering
- `create.php` - Processes new task submissions
- `actions.php` - Handles task completion and deletion
- `src/storage.php` - Reads and writes task data
- `src/validation.php` - Validates task input
- `data/tasks.json` - Stores saved tasks
- `public/` - Public entry points and CSS
- `README.md` - Project documentation

## UML Diagrams

The project includes a Class Diagram and a Use Case Diagram.

### Class Diagram
![Class Diagram](WebTechProject3ClassDiagram.drawio.png)

### Use Case Diagram
![Use Case Diagram](WebTechProject3UseCaseDiagram.drawio.png)

## Screenshots

Application screenshots will be added to this section once the required screenshots are captured.

Screenshots will demonstrate:
- Task creation and validation
- Successful task creation
- Unfiltered and filtered task lists
- Task completion before and after
- Task deletion before and after
- Responsive layouts

## Group Evaluation

Group member evaluations are completed using the provided GroupEval form.

## Project Summary

The Task Manager demonstrates PHP form handling, server-side validation, JSON file storage, task management operations, and a responsive web interface.