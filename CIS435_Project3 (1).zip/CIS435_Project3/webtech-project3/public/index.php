<?php
// Group members: Mouath Nasri, Nathalie Agalo, Faras Abueida
require_once __DIR__ . '/../index.php';