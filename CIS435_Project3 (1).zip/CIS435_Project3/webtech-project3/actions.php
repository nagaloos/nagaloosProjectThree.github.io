<?php
// Group members: Mouath Nasri, Nathalie Agalo, Faras Abueida

session_start();

require_once __DIR__ . '/src/storage.php';

// Only allow POST requests.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php', true, 303);
    exit;
}

// Read the requested action and task ID.
$action = $_POST['action'] ?? '';
$taskId = $_POST['id'] ?? '';

// Validate the action and task ID.
if (
    !is_string($action) ||
    !in_array($action, ['complete', 'delete'], true) ||
    !is_string($taskId) ||
    $taskId === ''
) {
    $_SESSION['flash'] = 'Invalid task action.';
    header('Location: index.php', true, 303);
    exit;
}

// Load all saved tasks.
$tasks = loadTasks();
$found = false;

// Find the task by its unique ID.
foreach ($tasks as $index => $task) {
    if (($task['id'] ?? '') !== $taskId) {
        continue;
    }

    $found = true;

    // Mark the selected task as completed.
    if ($action === 'complete') {
        if (empty($task['completed'])) {
            $tasks[$index]['completed'] = true;
            $_SESSION['flash'] = 'Task completed successfully.';
        } else {
            $_SESSION['flash'] = 'Task is already completed.';
        }
    }

    // Delete the selected task.
    if ($action === 'delete') {
        unset($tasks[$index]);
        $tasks = array_values($tasks);

        $_SESSION['flash'] = 'Task deleted successfully.';
    }

    break;
}

// Save the updated task list.
if ($found) {
    saveTasks($tasks);
} else {
    $_SESSION['flash'] = 'Task not found.';
}

// Redirect back to the task list.
header('Location: index.php', true, 303);
exit;