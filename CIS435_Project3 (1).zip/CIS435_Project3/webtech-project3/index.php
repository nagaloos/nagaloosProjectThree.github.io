<?php
// Group members: Mouath Nasri, Nathalie Agalo, Faras Abueida
session_start();

require_once __DIR__ . '/src/storage.php';

// Load tasks from the server-side JSON file.
$tasks = loadTasks();

//Calculate task controls
$totalCount = count($tasks);

$completedCount = 0;

foreach ($tasks as $task) {
    if ($task['completed'] ?? false) {
        $completedCount++;
    }
}

$pendingCount = $totalCount - $completedCount;


// Read search and priority filters from the URL.
$searchQuery = is_string($_GET['q'] ?? null)
    ? trim($_GET['q']) : '';

$searchQuery = substr($searchQuery, 0, 120);

$priorityFilter = is_string($_GET['priority'] ?? null)
    ? trim($_GET['priority']) : '';

// Accept only valid priority values.
if (!in_array($priorityFilter, ['Low', 'Medium', 'High'], true)) {
    $priorityFilter = '';
}

// Read and validate the status and sort selections.
$statusFilter = is_string($_GET['status'] ?? null)
    ? trim($_GET['status']) : 'all';

if (!in_array($statusFilter, ['all', 'active', 'completed'], true)) {
    $statusFilter = 'all';
}

$sortOrder = is_string($_GET['sort'] ?? null)
    ? trim($_GET['sort']) : 'newest';

if (!in_array($sortOrder, ['newest', 'due', 'priority'], true)) {
    $sortOrder = 'newest';
}

// Filter tasks based on search text, priority, and completion status.
$filteredTasks = array_values(array_filter(
    $tasks,
    function ($task) use ($searchQuery, $priorityFilter, $statusFilter) {

        $title = $task['title'] ?? '';
        $description = $task['description'] ?? '';

        // Case-insensitive search.
        $matchesSearch = $searchQuery === ''
            || stripos($title, $searchQuery) !== false
            || stripos($description, $searchQuery) !== false;

        // Match the selected priority.
        $matchesPriority = $priorityFilter === ''
            || ($task['priority'] ?? '') === $priorityFilter;

        // Match the selected completion status.
        $matchesStatus = $statusFilter === 'all'
            || ($statusFilter === 'active' && empty($task['completed']))
            || ($statusFilter === 'completed' && !empty($task['completed']));

        return $matchesSearch && $matchesPriority && $matchesStatus;
    }
));

// Sort the filtered tasks. Tasks without due dates appear last.
usort($filteredTasks, function ($a, $b) use ($sortOrder) {
    if ($sortOrder === 'due') {
        $aDue = $a['due'] ?? '';
        $bDue = $b['due'] ?? '';

        if ($aDue === '' && $bDue !== '') return 1;
        if ($bDue === '' && $aDue !== '') return -1;

        $comparison = strcmp($aDue, $bDue);
        if ($comparison !== 0) return $comparison;
    } elseif ($sortOrder === 'priority') {
        $priorityRanks = ['High' => 0, 'Medium' => 1, 'Low' => 2];
        $aRank = $priorityRanks[$a['priority'] ?? ''] ?? 3;
        $bRank = $priorityRanks[$b['priority'] ?? ''] ?? 3;

        $comparison = $aRank <=> $bRank;
        if ($comparison !== 0) return $comparison;
    }

    // Default and tie-breaker: newest tasks first.
    return strcmp($b['createdAt'] ?? '', $a['createdAt'] ?? '');
});

// Retrieve messages and form values from the session.
$flash = $_SESSION['flash'] ?? '';
$formErrors = $_SESSION['form_errors'] ?? [];
$formValues = $_SESSION['form_values'] ?? [];

// Clear messages after retrieving them.
unset(
    $_SESSION['flash'],
    $_SESSION['form_errors'],
    $_SESSION['form_values']
);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Task Manager | WebTech Project 3</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <a class="skip" href="#main">Skip to main content</a>

    <header class="top">
        <div class="wrap head">
            <div>
                <span class="eyebrow">WEBTECH PROJECT 3</span>
                <h1>Task Manager</h1>
                <p>Keep your work organized, one task at a time.</p>
            </div>
            <span class="head-icon" aria-hidden="true">✓</span>
        </div>
    </header>

    <main id="main" class="wrap">

<?php if ($flash !== ''): ?>
    <p role="status" class="success-message">
        <?= htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<?php if (!empty($formErrors)): ?>
    <div role="alert" class="error-message">
        <strong>Please correct the following errors:</strong>

        <ul>
            <?php foreach ($formErrors as $error): ?>
                <li>
                    <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

        <section class="summary" aria-label="Task overview">
            <div class="metric">
                <span>Total tasks</span>
                <strong id="total"><?= $totalCount ?></strong>
            </div>

            <div class="metric">
                <span>To do</span>
                <strong id="pending"><?= $pendingCount ?></strong>
            </div>

            <div class="metric">
                <span>Completed</span>
                <strong id="done"><?= $completedCount ?></strong>
            </div>
        </section>

        <div class="layout">

            <section class="panel" aria-labelledby="form-title">
                <div class="sectionhead">
                    <h2 id="form-title">Add a task</h2>
                    <p>Fields marked * are required.</p>
                </div>

                <form id="task-form" action="create.php" method="POST" novalidate>
                    <input id="task-id" type="hidden">

                    <div class="field">
                        <label for="title">
                            Task title <span aria-hidden="true">*</span>
                        </label>
                        <input
                            id="title"
                            name="title"
                            maxlength="120"
                            required
                            aria-required="true"
                            aria-describedby="title-error"
                            placeholder="e.g. Finish project report"
                            value="<?= htmlspecialchars($formValues['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                        >
                        <span class="error" id="title-error">
                            <?= htmlspecialchars($formErrors['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </span>
                    </div>

                    <div class="field">
                        <label for="description">Description</label>
                        <textarea
                            id="description"
                            name="description"
                            rows="4"
                            maxlength="1000"
                            placeholder="Add details about this task"
                        ><?= htmlspecialchars($formValues['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>

                        <span class="error" id="description-error">
                            <?= htmlspecialchars($formErrors['description'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </span>
                    </div>

                    <div class="field">
                        <label for="priority">Priority</label>
                        <select id="priority" name="priority">
                            <option value="Low"
                                <?= ($formValues['priority'] ?? 'Medium') === 'Low' ? 'selected' : '' ?>>
                                Low
                            </option>

                            <option value="Medium"
                                <?= ($formValues['priority'] ?? 'Medium') === 'Medium' ? 'selected' : '' ?>>
                                Medium
                            </option>

                            <option value="High"
                                <?= ($formValues['priority'] ?? 'Medium') === 'High' ? 'selected' : '' ?>>
                                High
                            </option>
                        </select>

                        <span class="error" id="priority-error">
                            <?= htmlspecialchars($formErrors['priority'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </span>
                    </div>

                    <div class="field">
                        <label for="due-date">
                            Due date <span class="optional">(optional)</span>
                        </label>
                        <input
                            id="due-date"
                            name="dueDate"
                            type="date"
                            aria-describedby="date-help"
                        >
                        <small id="date-help">
                            Leave blank if there is no deadline.
                        </small>

                        <span class="error" id="due-error">
                            <?= htmlspecialchars($formErrors['dueDate'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </span>
                    </div>

                    <div class="actions">
                        <button
                            class="primary"
                            type="submit"
                            id="submit-button"
                        >
                            Add task
                        </button>

                        <button
                            class="secondary"
                            type="button"
                            id="cancel-button"
                            hidden
                        >
                            Cancel editing
                        </button>
                    </div>
                </form>
            </section>

            <section class="panel tasks-panel" aria-labelledby="tasks-title">
                <div class="sectionhead">
                    <h2 id="tasks-title">Your tasks</h2>
                    <p>Review and manage your tasks.</p>
                </div>

<form action="index.php" method="GET" class="filters">
    <div class="field">
        <label for="search-query">Search tasks</label>
        <input
            type="search"
            id="search-query"
            name="q"
            placeholder="Search title or description"
            value="<?= htmlspecialchars($searchQuery, ENT_QUOTES, 'UTF-8') ?>"
        >
    </div>

    <div class="field">
        <label for="priority-filter">Filter by priority</label>
        <select id="priority-filter" name="priority">
            <option value="">All priorities</option>

            <option value="Low"
                <?= $priorityFilter === 'Low' ? 'selected' : '' ?>>
                Low
            </option>

            <option value="Medium"
                <?= $priorityFilter === 'Medium' ? 'selected' : '' ?>>
                Medium
            </option>

            <option value="High"
                <?= $priorityFilter === 'High' ? 'selected' : '' ?>>
                High
            </option>
        </select>
    </div>

    <div class="field">
        <label for="status-filter">Filter by status</label>
        <select id="status-filter" name="status">
            <option value="all" <?= $statusFilter === 'all' ? 'selected' : '' ?>>All tasks</option>
            <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>To do</option>
            <option value="completed" <?= $statusFilter === 'completed' ? 'selected' : '' ?>>Completed</option>
        </select>
    </div>

    <div class="field">
        <label for="sort-order">Sort tasks</label>
        <select id="sort-order" name="sort">
            <option value="newest" <?= $sortOrder === 'newest' ? 'selected' : '' ?>>Newest first</option>
            <option value="due" <?= $sortOrder === 'due' ? 'selected' : '' ?>>Due date</option>
            <option value="priority" <?= $sortOrder === 'priority' ? 'selected' : '' ?>>Priority</option>
        </select>
    </div>

    <div class="actions">
        <button type="submit" class="primary">
            Apply Filters
        </button>

        <a href="index.php" class="secondary">
            Clear Filters
        </a>
    </div>
</form>

<div id="task-list" class="task-list" aria-label="Task list">
    <?php foreach ($filteredTasks as $task): ?>
        <article class="task<?= !empty($task['completed']) ? ' done' : '' ?>">
            <div class="task-info">
                <h3>
                    <?= htmlspecialchars($task['title'], ENT_QUOTES, 'UTF-8') ?>
                </h3>

                <?php if (!empty($task['description'])): ?>
                    <p>
                        <?= htmlspecialchars($task['description'], ENT_QUOTES, 'UTF-8') ?>
                    </p>
                <?php endif; ?>

                <div class="task-meta">
                    <span class="badge">
                        <?= htmlspecialchars($task['priority'], ENT_QUOTES, 'UTF-8') ?>
                    </span>

                    <span class="badge">
                        <?= !empty($task['completed']) ? 'Completed' : 'Open' ?>
                    </span>

                    <?php if (!empty($task['due'])): ?>
                        <span>
                            Due:
                            <?= htmlspecialchars($task['due'], ENT_QUOTES, 'UTF-8') ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="task-actions">
                <?php if (empty($task['completed'])): ?>
                    <form action="actions.php" method="POST">
                        <input
                            type="hidden"
                            name="id"
                            value="<?= htmlspecialchars($task['id'], ENT_QUOTES, 'UTF-8') ?>"
                        >
                        <input type="hidden" name="action" value="complete">

                        <button type="submit" class="secondary">
                            Complete
                        </button>
                    </form>
                <?php endif; ?>

                <form action="actions.php" method="POST">
                    <input
                        type="hidden"
                        name="id"
                        value="<?= htmlspecialchars($task['id'], ENT_QUOTES, 'UTF-8') ?>"
                    >
                    <input type="hidden" name="action" value="delete">

                    <button type="submit" class="danger">
                        Delete
                    </button>
                </form>
            </div>
        </article>
    <?php endforeach; ?>
</div>

            <?php if (empty($filteredTasks)): ?>
                <div id="empty-state" class="empty">
                    <div aria-hidden="true" class="empty-icon">☑</div>
                    <h3>No tasks to show</h3>
                    <p>
                        <?php if (empty($tasks)): ?>
                            Add a task to get started.
                        <?php else: ?>
                            No tasks match your search or selected priority.
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
            </section>

        </div>

        <p class="footer">
            WebTech Project 3 · Task, TaskRepository &amp; Validator · Data saved in this browser
        </p>

    </main>

    <div
        id="announcements"
        class="sr-only"
        role="status"
        aria-live="polite"
        aria-atomic="true"
    ></div>

    <dialog
        id="delete-dialog"
        aria-labelledby="delete-title"
        aria-describedby="delete-message"
    >
        <h2 id="delete-title">Delete task?</h2>
        <p id="delete-message">
            This task will be permanently deleted.
        </p>

        <div class="actions">
            <button
                id="confirm-delete"
                class="danger"
                type="button"
            >
                Delete task
            </button>

            <button
                id="cancel-delete"
                class="secondary"
                type="button"
            >
                Cancel
            </button>
        </div>
    </dialog>

    <!-- <script src="app.js" defer></script> -->
</body>

</html>