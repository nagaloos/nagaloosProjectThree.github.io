//Group members: Firas Abueida, Nathalie Agalo-os, Mouath Nasri

'use strict';
// Task class from the provided class diagram.
class Task {
  constructor({id, title, description = '', priority = 'Medium', dueDate = null, completed = false, createdAt = new Date().toISOString()}) {
    this.id = id; this.title = title; this.description = description;
    this.priority = priority; this.dueDate = dueDate; this.completed = Boolean(completed); this.createdAt = createdAt;
  }
  setTitle(value) { this.title = value; }
  setDescription(value) { this.description = value; }
  setPriority(value) { this.priority = value; }
  setDueDate(value) { this.dueDate = value || null; }
}
// JSON serialization persisted in localStorage, with the same all/add/update/delete API.
class TaskRepository {
  constructor(path = 'webtech-project3-tasks') { this.path = path; }
  all() { try { const value = JSON.parse(localStorage.getItem(this.path) || '[]'); return Array.isArray(value) ? value.filter(x => x && typeof x.id === 'string' && typeof x.title === 'string').map(x => new Task(x)) : []; } catch { return []; } }
  save(tasks) { localStorage.setItem(this.path, JSON.stringify(tasks)); }
  add(task) { const tasks = this.all(); tasks.push(task); this.save(tasks); }
  update(task) { const tasks = this.all(); const index = tasks.findIndex(t => t.id === task.id); if(index < 0) throw Error('Task not found'); tasks[index] = task; this.save(tasks); }
  delete(id) { this.save(this.all().filter(t => t.id !== id)); }
}
class Validator {
  static validateCreate(input) {
    const errors = {}; const title = String(input.title || '').trim();
    const description = String(input.description || '').trim();
    const priority = String(input.priority || 'Medium');
    const dueDate = input.dueDate || null;
    if (!title) errors.title = 'Enter a task title.';
    else if (title.length > 120) errors.title = 'The title must be 120 characters or fewer.';
    if (description.length > 1000) errors.description = 'The description must be 1,000 characters or fewer.';
    if (!['Low', 'Medium', 'High'].includes(priority)) errors.priority = 'Choose a valid priority.';
    if (dueDate && (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate) || Number.isNaN(Date.parse(dueDate + 'T12:00:00')))) errors.dueDate = 'Choose a valid due date.';
    return {isValid: Object.keys(errors).length === 0, errors, sanitized: {title, description, priority, dueDate}};
  }
}
const repository = new TaskRepository();
const $ = id => document.getElementById(id);
const form = $('task-form'); let deletingId = null; let deleteReturnFocus = null;
function announce(message) { $('announcements').textContent = ''; requestAnimationFrame(() => { $('announcements').textContent = message; }); }
function formatDate(date) { return new Date(date + 'T12:00:00').toLocaleDateString(undefined, {year:'numeric',month:'short',day:'numeric'}); }
function resetForm() { form.reset(); $('task-id').value = ''; $('form-title').textContent = 'Add a task'; $('submit-button').textContent = 'Add task'; $('cancel-button').hidden = true; $('title').removeAttribute('aria-invalid'); $('title-error').textContent = ''; }
function element(tag, className, content) { const node = document.createElement(tag); if(className) node.className = className; if(content !== undefined) node.textContent = content; return node; }
function render() {
  const all = repository.all(); $('total').textContent = all.length; $('pending').textContent = all.filter(t => !t.completed).length; $('done').textContent = all.filter(t => t.completed).length;
  const filter = $('status-filter').value, sort = $('sort-order').value;
  const visible = all.filter(t => filter === 'all' || (filter === 'active' ? !t.completed : t.completed));
  const rank = {High:0,Medium:1,Low:2};
  visible.sort((a,b) => sort === 'priority' ? (rank[a.priority] ?? 3) - (rank[b.priority] ?? 3) : sort === 'due' ? (a.dueDate || '9999').localeCompare(b.dueDate || '9999') : b.createdAt.localeCompare(a.createdAt));
  const list = $('task-list'); list.replaceChildren(); $('empty-state').hidden = visible.length > 0;
  for (const task of visible) {
    const article = element('article','task' + (task.completed ? ' done' : '')); article.setAttribute('aria-label',task.title);
    const top = element('div','task-top'); const check = element('input','task-check'); check.type = 'checkbox'; check.checked = task.completed; check.id = 'complete-' + task.id; check.setAttribute('aria-label',(task.completed ? 'Mark as not completed: ' : 'Mark as completed: ') + task.title);
    check.addEventListener('change',() => { task.completed = check.checked; try { repository.update(task); render(); announce(task.title + (task.completed ? ' completed.' : ' marked as to do.')); } catch { announce('Could not save task. Check browser storage permissions.'); render(); } });
    const content = element('div','task-content'); const heading = element('h3','',task.title); content.append(heading);
    if(task.description) content.append(element('p','task-desc',task.description));
    const meta = element('div','meta'); meta.append(element('span','tag ' + task.priority.toLowerCase(),task.priority + ' priority'));
    if(task.dueDate) meta.append(element('span','tag','Due ' + formatDate(task.dueDate)));
    meta.append(element('span','tag',task.completed ? 'Completed' : 'To do')); content.append(meta); top.append(check,content); article.append(top);
    const actions = element('div','task-actions'); const edit = element('button','secondary','Edit'); edit.type = 'button'; edit.setAttribute('aria-label','Edit task: ' + task.title);
    edit.addEventListener('click',() => { $('task-id').value = task.id; $('title').value = task.title; $('description').value = task.description; $('priority').value = task.priority; $('due-date').value = task.dueDate || ''; $('form-title').textContent = 'Edit task'; $('submit-button').textContent = 'Save changes'; $('cancel-button').hidden = false; $('title-error').textContent = ''; $('title').removeAttribute('aria-invalid'); $('title').focus(); announce('Editing ' + task.title); });
    const del = element('button','secondary','Delete'); del.type = 'button'; del.setAttribute('aria-label','Delete task: ' + task.title);
    del.addEventListener('click',() => { deletingId = task.id; deleteReturnFocus = del; $('delete-message').textContent = 'Delete “' + task.title + '”? This action cannot be undone.'; $('delete-dialog').showModal(); $('cancel-delete').focus(); });
    actions.append(edit,del); article.append(actions); list.append(article);
  }
}
form.addEventListener('submit',event => { event.preventDefault(); const result = Validator.validateCreate({title:$('title').value,description:$('description').value,priority:$('priority').value,dueDate:$('due-date').value}); $('title-error').textContent = result.errors.title || ''; if(result.errors.title) $('title').setAttribute('aria-invalid','true'); else $('title').removeAttribute('aria-invalid'); if(!result.isValid) { announce(Object.values(result.errors).join(' ')); if(result.errors.title) $('title').focus(); return; }
  try { const id = $('task-id').value; if(id) { const task = repository.all().find(t => t.id === id); if(!task) throw Error('Task not found'); task.setTitle(result.sanitized.title); task.setDescription(result.sanitized.description); task.setPriority(result.sanitized.priority); task.setDueDate(result.sanitized.dueDate); repository.update(task); announce('Task updated: ' + task.title); } else { const task = new Task({id: crypto.randomUUID(),...result.sanitized}); repository.add(task); announce('Task added: ' + task.title); } resetForm(); render(); $('title').focus(); } catch { announce('Unable to save task. Make sure browser storage is enabled.'); }
});
$('cancel-button').addEventListener('click',() => { resetForm(); $('title').focus(); announce('Editing canceled.'); });
$('status-filter').addEventListener('change',() => { render(); announce('Task filter updated.'); });
$('sort-order').addEventListener('change',() => { render(); announce('Task order updated.'); });
$('cancel-delete').addEventListener('click',() => $('delete-dialog').close());
$('confirm-delete').addEventListener('click',() => { const task = repository.all().find(t => t.id === deletingId); try { repository.delete(deletingId); if($('task-id').value === deletingId) resetForm(); $('delete-dialog').close(); render(); $('tasks-title').focus?.(); announce('Task deleted: ' + (task?.title || 'task')); } catch { $('delete-dialog').close(); announce('Unable to delete task.'); } });
$('delete-dialog').addEventListener('close',() => { if(deleteReturnFocus?.isConnected) deleteReturnFocus.focus(); else $('status-filter').focus(); deletingId = null; });
render();
