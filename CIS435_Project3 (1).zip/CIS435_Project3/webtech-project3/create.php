<?php
// Group members: Mouath Nasri, Nathalie Agalo, Faras Abueida

session_start();

require_once __DIR__ . '/src/storage.php';
require_once __DIR__ . '/src/validation.php';

//Only accept form submissions using POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header ('Location: index.php', true, 303);
    exit;
}

// Validate the submitted task information.
$result = validateTask($_POST);

// If validation fails, remember the errors and inputs.
if (!empty($result['errors'])) {
    $_SESSION['form_errors'] = $result['errors'];
    $_SESSION['form_values'] = $result['task'];

    header('Location: index.php', true, 303);
    exit;
}

// Prepare the new task for storage.
$task = $result['task'];

$task['id'] = bin2hex(random_bytes(16));
$task['completed'] = false;
$task['createdAt'] = gmdate('c');

// Load existing tasks and append the new task.
$tasks = loadTasks();
$tasks[] = $task;

// Save everything to the JSON file.
saveTasks($tasks);

// Store a success message for the next page.
$_SESSION['flash'] = 'Task added successfully.';

// Redirect to the task list to prevent double submissions.
header('Location: index.php', true, 303);
exit;