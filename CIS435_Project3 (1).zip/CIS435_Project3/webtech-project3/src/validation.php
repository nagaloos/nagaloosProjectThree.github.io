<?php
// Group members: Mouath Nasri, Nathalie Agalo, Faras Abueida

// Validate and clean task information submitted by a user.
function validateTask(array $input): array
{
    $errors = [];

    // Read submitted values safely.
    $title = is_string($input['title'] ?? null)
        ? trim($input['title']) : '';

    $description = is_string($input['description'] ?? null)
        ? trim($input['description']) : '';

    $priority = is_string($input['priority'] ?? null)
        ? trim($input['priority']) : '';

    $due = is_string($input['dueDate'] ?? null)
        ? trim($input['dueDate']) : '';

    // Validate the required task title.
    if ($title === '') {
        $errors['title'] = 'Task title is required.';
    } elseif (strlen($title) > 120) {
        $errors['title'] = 'Title cannot exceed 120 characters.';
    }

    // Validate description length.
    if (strlen($description) > 1000) {
        $errors['description'] =
            'Description cannot exceed 1000 characters.';
    }

    // Only allow the three supported priorities.
    $allowedPriorities = ['Low', 'Medium', 'High'];

    if (!in_array($priority, $allowedPriorities, true)) {
        $errors['priority'] = 'Please select a valid priority.';
    }

    // Validate the optional due date.
    if ($due !== '') {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) {
            $errors['dueDate'] = 'Use the YYYY-MM-DD date format.';
        } else {
            [$year, $month, $day] = array_map(
                'intval',
                explode('-', $due)
            );

            if (!checkdate($month, $day, $year)) {
                $errors['dueDate'] = 'Please enter a valid date.';
            }
        }
    }

    // Return validation errors and cleaned task values.
    return [
        'errors' => $errors,
        'task' => [
            'title' => $title,
            'description' => $description,
            'priority' => $priority,
            'due' => $due === '' ? null : $due
        ]
    ];
}