<?php
// Group members: Mouath Nasri, Nathalie Agalo, Faras Abueida

//Location of the JSON file where tasks are stored.
function tasksFilePath(): string
{
    return __DIR__ . '/../data/tasks.json';
}

//All saved tasks read from the JSON file.
function loadTasks(): array
{
    $path = tasksFilePath();

    if (!file_exists($path)) {
        return [];
    }

    $contents = file_get_contents($path);

    if ($contents === false) {
        throw new RuntimeException('Unable to identify tasks.');
    }

    $tasks = json_decode($contents, true, 512, JSON_THROW_ON_ERROR);

    if (!is_array($tasks)) {
        throw new RuntimeException('Invalid task data.');
    }

    return $tasks;
}

// Save updated task list to the JSON file.
function saveTasks(array $tasks): void
{
    $path = tasksFilePath();

    $json = json_encode(
        $tasks,
        JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR
    );

    if (file_put_contents($path, $json, LOCK_EX) === false) {
        throw new RuntimeException('Unable to save tasks.');
    }
}